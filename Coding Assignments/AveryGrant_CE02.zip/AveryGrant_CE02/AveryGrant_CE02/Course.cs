﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AveryGrant_CE02
{
    class Course
    {
        private string _courseTitle;
        private string _courseDescript;
        private Teacher _teacher;
        private Student[] _students;
        private int studentInCourse;

        public string CourseTitle
        {
            get {return _courseTitle; }
            set {_courseTitle = value; }
        }

        public string CourseDescript
        {
            get {return _courseDescript; }
            set {_courseDescript = value; }
        }

        public Teacher Teacher
        {
            get { return _teacher; }
            set { _teacher = value; }
        }

        public Student[] Student
        {
            get { return _students; }
            set { _students = value; }
        }

        public int StudentInCourse
        {
            get { return studentInCourse; }
            set { studentInCourse = value; }
        }


        public Course(string title, string description, int students)
        {
            _courseTitle = title;
            _courseDescript = description;
            studentInCourse = students;
        }

        public void DisplayCourse()
        {
            Console.WriteLine("Your current course: \n");
            Console.WriteLine($"Course name: {_courseTitle}");
            Console.WriteLine($"Course description: {_courseDescript}");
            Console.WriteLine($"Courses Teacher: {_teacher}");
            Console.WriteLine($"Students taking the course: {_students}");
        }

    }
}
