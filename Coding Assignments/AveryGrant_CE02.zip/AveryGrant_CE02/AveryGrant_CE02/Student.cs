﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AveryGrant_CE02
{
    class Student : Person
    {
        // Students Grade
        public int _studentGrade;

        public Student(string name, string description, int age, int studentGrade) : base(name, description, age)
        {
            _studentGrade = studentGrade;
        }

        public void DisplayStudent()
        {
            
            Console.WriteLine($"Welcome New Student: ");
        }
    }
}
