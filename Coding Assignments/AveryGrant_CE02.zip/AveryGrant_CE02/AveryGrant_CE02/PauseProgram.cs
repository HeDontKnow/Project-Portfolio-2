﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AveryGrant_CE02
{
    class PauseProgram
    {
        public static void PauseBeforeContinuing()
        {
            Console.WriteLine("Press a key to continue");
            Console.ReadKey();
        }
    }
}
