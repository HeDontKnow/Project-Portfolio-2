﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AveryGrant_CE02
{
    class Person
    {
        private string _name;
        private string _descript;
        private int _age;

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public string Description
        {

            get { return _descript; }
            set { _descript = value; }
        }

        public int Age
        {
            get { return _age; }
            set { _age = value; }
        }



        public Person(string name, string description, int age)
        {
            _name = name;
            _descript = description;
            _age = age;
        }
    }
}
