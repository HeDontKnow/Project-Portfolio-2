﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AveryGrant_CE02
{
    class Teacher : Person
    {
        // Create an array for teacher skills
        public string[] _teacherSkills;

        public string[] TeacherSkills
        {
            get { return _teacherSkills; }
            set { _teacherSkills = value; }
        }

        public Teacher(string name, string description, int age) : base(name, description, age)
        {
          
        }

        public void DisplayTeacher()
        {
            Console.WriteLine("Welcome New Teacher: ");
        }
    }
}
