﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AveryGrant_CE02
{
    class Program
    {
        static void Main(string[] args)
        {

            bool programIsRunning = true;
            Course currentCourse = null;

            while (programIsRunning)
            {

                Console.Clear();

                Console.Write(
                   "1. Create Course\n" +
                   "2. Create Teacher\n" +
                   "3. Add Students\n" +
                   "4. Display\n" +
                   "5. Exit\n" +
                   "Select an option: ");
                string input = Validation.Text(Console.ReadLine().ToLower(), "Please do not leave blank or empty.");

                switch (input)
                {
                    case "1":
                    case "create a course":
                        {
                            currentCourse = CreateCourse();
                        }
                        break;
                    case "2":
                    case "create a teacher":
                        {
                            CreateTeacher(currentCourse);
                        }
                        break;
                    case "3":
                    case "add students":
                        {
                            
                          
                           
                               AddStudents(currentCourse);
                               
                            
                        }
                        break;
                    case "4":
                    case "display":
                        {
                            DisplayCourseInfo(currentCourse);
                        }
                        break;
                    case "5":
                    case "exit":
                        {
                            programIsRunning = false;
                        }
                        break;
                }

               
            }
            PauseProgram.PauseBeforeContinuing();

        }

        static Course CreateCourse()
        {
            Course newCourse = null;

            Console.WriteLine("What is the course's title? ");
            string title = Validation.Text(Console.ReadLine(), "Please do not leave blank or empty.");

            Console.WriteLine("What is the course's description? ");
            string descript = Console.ReadLine();

            int studentInCourse = Validation.GetInt("How many students are in this course?:  ");

            if (newCourse == null)
            {
                Console.WriteLine("Please create a course first:");
            }
            else
            {
                Console.WriteLine("You have successfully created a course.");
                newCourse = new Course(title, descript, 60);
               
            }


            return newCourse;
        }

        static Teacher CreateTeacher(Course currentCourse)
        {
            Teacher newTeacher = null;

            Console.WriteLine("What is the teachers name? ");
            string name = Validation.Text(Console.ReadLine(), "Please do not leave blank or empty");

            Console.WriteLine("What is the teachers description? ");
            string descript = Validation.Text(Console.ReadLine(), "Please do not leave blank or empty");

            int age = Validation.GetInt(24,80,"What is the age of the teacher?:  ");

            
            Console.WriteLine("What are the number and name of skills you have");
            string skills = Validation.Text(Console.ReadLine(), "Please do not leave blank or empty ");
          

            if (newTeacher == null)
            {
                Console.WriteLine("Please create a teacher first:");
            }
            else
            {
                Console.WriteLine("You have created a teacher for a course.");
                newTeacher = new Teacher(name, descript, age);
                currentCourse.Teacher = newTeacher;
            }


            return newTeacher;
        }

        static void AddStudents(Course currentCourse)
        {
            Student student = null;

            Console.WriteLine("What is the students name? ");
            string name = Validation.Text(Console.ReadLine(), "Please do not leave blank or empty");

            Console.WriteLine("What is the students description? ");
            string descript = Validation.Text(Console.ReadLine(), "Please do not leave blank or empty");

            int age = Validation.GetInt(24, 80, "What is the age of the student?:  ");

            int grade = Validation.GetInt("What is the grade of the student?:  ");

            if (student == null)
            {
                Console.WriteLine("Please add students");
            }
            else 
            {
                Console.WriteLine("You have added a student to the course");
                student = new Student(name, descript, age, grade);
            }


        }


        public static void DisplayCourseInfo(Course currentCourse)
        {
            Console.Clear();
            if (currentCourse == null)
            {
                Console.WriteLine("Please create a course first.");
            }
            else
            {

                currentCourse.DisplayCourse();
                /*Console.WriteLine($"Course name: {currentCourse.CourseTitle}");
                Console.WriteLine($"Course description: {currentCourse.CourseDescript}");
                Console.WriteLine($"Courses Teacher: {currentCourse.Teacher.Name}");
                Console.WriteLine($"Students taking the course: {currentCourse.StudentInCourse}");*/
            }


        }
    }
}
